
import React, { useState } from 'react';
import { Mic, MicOff, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';

type Message = {
  id: number;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
};

export const VoiceAssistant = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your voice assistant. How can I help with your mental wellbeing today?",
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  
  const handleSend = () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };
    
    setMessages([...messages, userMessage]);
    setInput('');
    
    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "I understand how you're feeling. Would you like to talk more about that?",
        "That sounds challenging. Have you tried any coping strategies that helped in the past?",
        "Thank you for sharing. Remember that it's okay to ask for help when you need it.",
        "I'm here to support you. Would it help to discuss some relaxation techniques?",
        "Your feelings are valid. Would you like me to suggest some resources that might help?"
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      
      const assistantMessage: Message = {
        id: messages.length + 2,
        text: randomResponse,
        sender: 'assistant',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    }, 1000);
  };
  
  const toggleRecording = () => {
    if (!isRecording) {
      setIsRecording(true);
      toast.info("Voice recognition started. (This is a simulation)");
      
      // Simulate voice recognition
      setTimeout(() => {
        const voiceTexts = [
          "I've been feeling anxious lately",
          "How can I improve my sleep?",
          "I need techniques to manage stress"
        ];
        
        const randomText = voiceTexts[Math.floor(Math.random() * voiceTexts.length)];
        setInput(randomText);
        setIsRecording(false);
        
        toast.success("Voice recognized!");
      }, 3000);
    } else {
      setIsRecording(false);
      toast.info("Voice recognition cancelled");
    }
  };
  
  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Voice Assistant</h1>
        <p className="text-gray-600">
          Talk to our AI assistant using voice or text. Your conversation is private and secure.
        </p>
      </div>
      
      <Card className="mb-4">
        <CardContent className="p-4 h-[400px] overflow-y-auto flex flex-col space-y-4">
          {messages.map((message) => (
            <div 
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                {message.sender === 'assistant' && (
                  <Avatar className="mr-2 h-8 w-8">
                    <AvatarFallback className="bg-purple-100 text-purple-600">AI</AvatarFallback>
                  </Avatar>
                )}
                <div 
                  className={`rounded-lg px-4 py-2 ${
                    message.sender === 'user' 
                      ? 'bg-purple-600 text-white ml-2' 
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  <p>{message.text}</p>
                  <p className={`text-xs mt-1 ${message.sender === 'user' ? 'text-purple-200' : 'text-gray-500'}`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
        <CardFooter className="p-4 border-t">
          <div className="flex items-center w-full space-x-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={toggleRecording}
                    className={isRecording ? "bg-red-100 text-red-600" : ""}
                  >
                    {isRecording ? <MicOff /> : <Mic />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{isRecording ? "Stop recording" : "Start voice input"}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            
            <Button 
              onClick={handleSend} 
              disabled={!input.trim()}
              size="icon"
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Voice Commands</CardTitle>
          <CardDescription>Try these phrases with the voice assistant</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-1 text-gray-600">
            <li>"Help me with relaxation techniques"</li>
            <li>"I'm feeling anxious"</li>
            <li>"How can I improve my sleep?"</li>
            <li>"Tell me about stress management"</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
};
