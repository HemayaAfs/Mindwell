
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Upload, FileText, Download, Filter } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// Sample data
const moodData = [
  { date: '01/01', mood: 7, anxiety: 4, sleep: 6 },
  { date: '01/02', mood: 6, anxiety: 5, sleep: 5 },
  { date: '01/03', mood: 8, anxiety: 3, sleep: 7 },
  { date: '01/04', mood: 7, anxiety: 3, sleep: 8 },
  { date: '01/05', mood: 5, anxiety: 6, sleep: 4 },
  { date: '01/06', mood: 6, anxiety: 5, sleep: 6 },
  { date: '01/07', mood: 7, anxiety: 4, sleep: 7 },
  { date: '01/08', mood: 8, anxiety: 3, sleep: 8 },
  { date: '01/09', mood: 7, anxiety: 4, sleep: 7 },
  { date: '01/10', mood: 6, anxiety: 5, sleep: 6 },
];

const dailyActivities = [
  { name: 'Exercise', value: 4 },
  { name: 'Meditation', value: 7 },
  { name: 'Social Interaction', value: 5 },
  { name: 'Work Stress', value: 6 },
  { name: 'Relaxation', value: 3 },
];

export const DataAnalysis = () => {
  const [timeRange, setTimeRange] = useState('10days');
  const [showUploadSection, setShowUploadSection] = useState(false);
  
  const handleUpload = () => {
    // Simulate file upload
    toast.success("Demo data loaded successfully");
    setShowUploadSection(false);
  };
  
  const handleDownloadReport = () => {
    toast.success("Report download started (simulation)");
  };
  
  return (
    <div className="w-full max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Mental Health Data Analysis</h1>
        <p className="text-gray-600">
          Visualize and analyze your mental health data to identify patterns and trends.
        </p>
      </div>
      
      {showUploadSection ? (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Upload Your Data</CardTitle>
            <CardDescription>
              Upload your mental health tracking data for analysis
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center h-40 border-2 border-dashed border-gray-300 rounded-md">
            <FileText className="h-10 w-10 text-gray-400 mb-2" />
            <p className="text-gray-500 mb-2">Drag and drop your file here, or click to browse</p>
            <Button variant="outline">Select File</Button>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setShowUploadSection(false)}>Cancel</Button>
            <Button className="bg-purple-600 hover:bg-purple-700" onClick={handleUpload}>Upload Data</Button>
          </CardFooter>
        </Card>
      ) : (
        <>
          <div className="flex flex-wrap gap-4 mb-6">
            <Button 
              variant="outline" 
              className="flex items-center" 
              onClick={() => setShowUploadSection(true)}
            >
              <Upload className="mr-2 h-4 w-4" />
              Upload Data
            </Button>
            
            <Button 
              variant="outline" 
              className="flex items-center"
              onClick={handleDownloadReport}
            >
              <Download className="mr-2 h-4 w-4" />
              Download Report
            </Button>
            
            <div className="ml-auto flex items-center gap-2">
              <Label htmlFor="timeRange" className="text-gray-600">Time Range:</Label>
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Select range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">7 Days</SelectItem>
                  <SelectItem value="10days">10 Days</SelectItem>
                  <SelectItem value="30days">30 Days</SelectItem>
                  <SelectItem value="3months">3 Months</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Mood & Anxiety Trends</CardTitle>
                <CardDescription>
                  Track how your mood and anxiety levels have changed over time
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={moodData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="mood" 
                      stroke="#8884d8" 
                      strokeWidth={2} 
                      name="Mood (0-10)"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="anxiety" 
                      stroke="#ff7300" 
                      strokeWidth={2} 
                      name="Anxiety (0-10)"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Sleep Quality</CardTitle>
                <CardDescription>
                  Monitor your sleep quality ratings over time
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={moodData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="sleep" 
                      stroke="#82ca9d" 
                      strokeWidth={2}
                      name="Sleep Quality (0-10)" 
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Daily Activities Impact</CardTitle>
              <CardDescription>
                See how different activities correlate with your mental wellbeing
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyActivities}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis domain={[0, 10]} />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    dataKey="value" 
                    fill="#8884d8" 
                    name="Impact Score (0-10)" 
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Insights & Recommendations</CardTitle>
              <CardDescription>
                AI-generated insights based on your data patterns
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-md border border-blue-100">
                <h3 className="font-medium text-blue-800 mb-1">Sleep Pattern Insight</h3>
                <p className="text-blue-700">Your sleep quality shows a positive correlation with mood ratings the following day. Consider maintaining a consistent sleep schedule.</p>
              </div>
              
              <div className="p-4 bg-purple-50 rounded-md border border-purple-100">
                <h3 className="font-medium text-purple-800 mb-1">Anxiety Trigger Pattern</h3>
                <p className="text-purple-700">Anxiety levels tend to increase mid-week. Consider implementing stress-reduction techniques on Tuesdays and Wednesdays.</p>
              </div>
              
              <div className="p-4 bg-green-50 rounded-md border border-green-100">
                <h3 className="font-medium text-green-800 mb-1">Positive Activity Correlation</h3>
                <p className="text-green-700">Meditation shows the strongest positive impact on your overall mood. Consider increasing meditation frequency.</p>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
};
