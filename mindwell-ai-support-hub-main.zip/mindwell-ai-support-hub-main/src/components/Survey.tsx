
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';

type Question = {
  id: number;
  text: string;
  options: string[];
};

const questions: Question[] = [
  {
    id: 1,
    text: "Over the past 2 weeks, how often have you felt little interest or pleasure in doing things?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: 2,
    text: "Over the past 2 weeks, how often have you felt down, depressed, or hopeless?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: 3,
    text: "Over the past 2 weeks, how often have you had trouble falling or staying asleep, or sleeping too much?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: 4,
    text: "Over the past 2 weeks, how often have you felt tired or had little energy?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: 5,
    text: "Over the past 2 weeks, how often have you felt nervous, anxious, or on edge?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
];

export const Survey = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isCompleted, setIsCompleted] = useState(false);
  
  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex) / questions.length) * 100;

  const handleNext = () => {
    if (selectedOption === null) {
      toast.error("Please select an option");
      return;
    }

    const optionIndex = currentQuestion.options.indexOf(selectedOption);
    setAnswers({...answers, [currentQuestion.id]: optionIndex});
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedOption(null);
    } else {
      setIsCompleted(true);
    }
  };

  const calculateScore = () => {
    let total = 0;
    Object.values(answers).forEach(value => {
      total += value;
    });
    return total;
  };

  const renderResult = () => {
    const score = calculateScore();
    let message = '';
    let recommendations = [];
    
    if (score <= 5) {
      message = "Your responses indicate minimal symptoms of anxiety or depression.";
      recommendations = [
        "Continue practicing self-care routines",
        "Maintain social connections",
        "Regular exercise can help maintain mental well-being"
      ];
    } else if (score <= 10) {
      message = "Your responses indicate mild symptoms that may benefit from some support.";
      recommendations = [
        "Consider practicing mindfulness meditation",
        "Regular exercise can help manage stress",
        "Maintain a consistent sleep schedule"
      ];
    } else {
      message = "Your responses suggest you may be experiencing significant symptoms.";
      recommendations = [
        "Consider speaking with a mental health professional",
        "Practice stress reduction techniques daily",
        "Ensure you're getting adequate sleep and nutrition",
        "Reach out to trusted friends or family for support"
      ];
    }

    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Your Assessment Results</CardTitle>
          <CardDescription>
            Based on your responses to the PHQ-9 and GAD-7 inspired questions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-lg font-medium">{message}</p>
          <div className="mt-6">
            <h3 className="text-lg font-medium mb-2">Recommendations:</h3>
            <ul className="list-disc pl-5 space-y-1">
              {recommendations.map((rec, index) => (
                <li key={index}>{rec}</li>
              ))}
            </ul>
          </div>
          <p className="mt-6 text-sm text-gray-500 italic">
            Note: This assessment is not a diagnostic tool. If you're experiencing distress,
            please consult with a qualified mental health professional.
          </p>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={() => {
              setIsCompleted(false);
              setCurrentQuestionIndex(0);
              setAnswers({});
              setSelectedOption(null);
            }}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            Take Assessment Again
          </Button>
        </CardFooter>
      </Card>
    );
  };

  if (isCompleted) {
    return renderResult();
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Mental Health Assessment</h1>
        <p className="text-gray-600">
          This brief questionnaire will help assess your current mental wellbeing. Your answers are private.
        </p>
      </div>
      
      <div className="mb-6">
        <div className="flex justify-between text-sm mb-1">
          <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{currentQuestion.text}</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup 
            value={selectedOption || ""} 
            onValueChange={setSelectedOption}
            className="space-y-3"
          >
            {currentQuestion.options.map((option, index) => (
              <div key={index} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`option-${index}`} />
                <Label htmlFor={`option-${index}`} className="cursor-pointer">
                  {option}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleNext} 
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            {currentQuestionIndex < questions.length - 1 ? "Next Question" : "Complete Assessment"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};
