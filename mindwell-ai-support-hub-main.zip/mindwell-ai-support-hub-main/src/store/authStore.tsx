
import { create } from 'zustand';

type User = {
  id: string;
  email: string;
  name?: string;
};

type AuthStore = {
  isAuthenticated: boolean;
  user: User | null;
  login: (email: string, password: string) => void;
  logout: () => void;
};

export const useAuthStore = create<AuthStore>((set) => ({
  isAuthenticated: false,
  user: null,
  login: (email, password) => {
    // In a real app, you would validate credentials against your backend
    // This is just a mock implementation
    if (email && password.length > 3) {
      set({
        isAuthenticated: true,
        user: {
          id: '1',
          email,
          name: email.split('@')[0],
        },
      });
    }
  },
  logout: () => {
    set({
      isAuthenticated: false,
      user: null,
    });
  },
}));
