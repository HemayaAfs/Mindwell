
import React from 'react';
import { useState } from 'react';
import { Brain, MessageCircle, FileSpreadsheet, Mic, ClipboardList, Lightbulb, LogOut } from 'lucide-react';
import { Survey } from '../components/Survey';
import { VoiceAssistant } from '../components/VoiceAssistant';
import { DataAnalysis } from '../components/DataAnalysis';
import { Login } from '../components/Login';
import { useAuthStore } from '../store/authStore';

type NavItem = {
  icon: React.ElementType;
  label: string;
  description: string;
  component?: React.ComponentType;
};

const navItems: NavItem[] = [
  {
    icon: FileSpreadsheet,
    label: 'Data Analysis',
    description: 'Upload and analyze mental health data to identify patterns',
    component: DataAnalysis,
  },
  {
    icon: MessageCircle,
    label: 'AI Chatbot',
    description: 'Talk to our supportive AI assistant for guidance',
    component: VoiceAssistant, // Using the VoiceAssistant component for Chatbot too
  },
  {
    icon: Mic,
    label: 'Voice Assistant',
    description: 'Voice-enabled support with multilingual capabilities',
    component: VoiceAssistant,
  },
  {
    icon: ClipboardList,
    label: 'Mental Health Survey',
    description: 'Take our assessment for personalized insights',
    component: Survey,
  },
  {
    icon: Lightbulb,
    label: 'Recommendations',
    description: 'Get personalized mental health tips and resources',
    component: DataAnalysis, // Using DataAnalysis for recommendations as it contains insights
  },
];

const Index = () => {
  const [activeSection, setActiveSection] = useState<string>('');
  const { isAuthenticated, user, logout } = useAuthStore();

  const ActiveComponent = navItems.find(item => item.label === activeSection)?.component;

  if (!isAuthenticated) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center cursor-pointer" onClick={() => setActiveSection('')}>
              <Brain className="h-8 w-8 text-purple-600" />
              <span className="ml-2 text-xl font-semibold text-gray-900">MindWell</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">{user?.email}</span>
              <button
                onClick={logout}
                className="flex items-center text-gray-600 hover:text-gray-900"
              >
                <LogOut className="h-5 w-5 mr-1" />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!activeSection ? (
          <>
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                Mental Health Support Platform
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Your comprehensive platform for mental health monitoring, support, and personal growth.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {navItems.map((item) => (
                <div
                  key={item.label}
                  className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 cursor-pointer"
                  onClick={() => setActiveSection(item.label)}
                >
                  <div className="flex items-center mb-4">
                    <item.icon className="h-8 w-8 text-purple-600" />
                    <h2 className="ml-3 text-xl font-semibold text-gray-900">{item.label}</h2>
                  </div>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              ))}
            </div>

            <section className="mt-16 bg-white rounded-xl shadow-sm p-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-6">About Our Platform</h2>
              <div className="prose max-w-none text-gray-600">
                <p className="mb-4">
                  Our mental health support platform is designed to provide comprehensive assistance
                  through data-driven insights, AI-powered conversations, and professional resources.
                  We believe in making mental health support accessible, personalized, and effective.
                </p>
                <p>
                  Whether you're looking to track your mental well-being, need someone to talk to,
                  or want to explore professional resources, we're here to help you on your journey
                  to better mental health.
                </p>
              </div>
            </section>

            <section className="mt-12 grid md:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-sm p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Getting Started</h2>
                <ol className="space-y-4 text-gray-600">
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 font-semibold">1</span>
                    <span className="ml-4">Create your profile to personalize your experience</span>
                  </li>
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 font-semibold">2</span>
                    <span className="ml-4">Take our mental health assessment</span>
                  </li>
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 font-semibold">3</span>
                    <span className="ml-4">Explore our AI chatbot for immediate support</span>
                  </li>
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 font-semibold">4</span>
                    <span className="ml-4">Review your personalized recommendations</span>
                  </li>
                </ol>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Privacy & Security</h2>
                <div className="prose text-gray-600">
                  <p className="mb-4">
                    Your privacy and security are our top priorities. All data is encrypted and stored
                    securely, and you have complete control over your information at all times.
                  </p>
                  <ul className="space-y-2">
                    <li>End-to-end encryption for all communications</li>
                    <li>HIPAA-compliant data storage</li>
                    <li>Anonymous usage options available</li>
                    <li>Regular security audits and updates</li>
                  </ul>
                </div>
              </div>
            </section>
          </>
        ) : (
          ActiveComponent && <ActiveComponent />
        )}
      </main>

      <footer className="bg-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-500">
            <p>© 2024 MindWell. All rights reserved.</p>
            <p className="mt-2">
              If you're experiencing a mental health emergency, please call 988 for immediate assistance.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
